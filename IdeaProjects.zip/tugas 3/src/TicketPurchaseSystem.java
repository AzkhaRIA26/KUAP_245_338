import java.util.Scanner;

public class TicketPurchaseSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Selamat datang di sistem pembelian tiket!");

        // Meminta input pengguna
        System.out.print("Masukkan nama Anda: ");
        String name = scanner.nextLine();
        if (name.isEmpty()) {
            System.out.println("Nama harus diisi.");
            return;
        }

        System.out.print("Masukkan tanggal kunjungan (format DD/MM/YYYY): ");
        String date = scanner.nextLine();
        if (date.isEmpty()) {
            System.out.println("Tanggal harus diisi.");
            return;
        }

        String dayOfWeek = getDayOfWeek(date);
        if (dayOfWeek == null) {
            System.out.println("Format tanggal salah atau tanggal tidak valid.");
            return;
        }

        // Menampilkan pilihan tiket
        System.out.println("Pilih jenis tiket:");
        System.out.println("1. Tiket Regular Dewasa (Rp 75,000)");
        System.out.println("2. Tiket Regular Anak (Rp 60,000)");
        System.out.println("3. Tiket Terusan Dewasa (Rp 100,000)");
        System.out.println("4. Tiket Terusan Anak (Rp 85,000)");
        System.out.print("Pilihan Anda: ");
        int choice = scanner.nextInt();

        // Menghitung harga
        double price = calculatePrice(choice, dayOfWeek);
        if (price == -1) {
            System.out.println("Pilihan tidak valid.");
            return;
        }

        System.out.println("Total harga: Rp " + price);
        System.out.println("Terima kasih telah membeli tiket. Selamat menikmati kunjungan Anda!");
    }

    public static String getDayOfWeek(String date) {
        // Asumsikan untuk contoh ini kita menggunakan tanggal sederhana
        // Misalnya, format tanggal adalah benar dan 01/01/2023 adalah hari Minggu
        if (!date.matches("\\d{2}/\\d{2}/\\d{4}")) {
            return null;
        }
        return "Sunday"; // untuk contoh, asumsikan selalu Minggu
    }

    public static double calculatePrice(int ticketType, String dayOfWeek) {
        double basePrice;
        switch (ticketType) {
            case 1:
                basePrice = 75000;
                break;
            case 2:
                basePrice = 60000;
                break;
            case 3:
                basePrice = 100000;
                break;
            case 4:
                basePrice = 85000;
                break;
            default:
                return -1; // Pilihan tiket tidak valid
        }

        if (dayOfWeek.equals("Saturday") || dayOfWeek.equals("Sunday")) {
            return basePrice * 1.20; // Harga naik 20% di akhir pekan
        }

        return basePrice;
    }
}

//Deskripsi Umum
//Program ini adalah aplikasi web atau mobile untuk pembelian tiket online sebuah wisata. Pengguna akan memilih jenis tiket, mengisi data pribadi, memilih tanggal kunjungan, dan melakukan pembayaran.
//
//        Spesifikasi Detail
//1. Jenis Tiket
//Tiket Regular Dewasa: Rp 75,000
//Tiket Regular Anak: Rp 60,000
//Tiket Terusan Dewasa: Rp 100,000
//Tiket Terusan Anak: Rp 85,000
//        2. Logika Harga Tiket
//Pada hari Sabtu dan Minggu, harga semua tiket akan naik sebesar 20%.
//        3. Input Pengguna
//Nama: Harus diisi. Jika kosong, tampilkan pesan error "Nama harus diisi."
//Hari: Ditetapkan berdasarkan tanggal yang dipilih. Jika pengguna tidak memilih tanggal, tampilkan pesan error "Tanggal harus diisi."
//Tanggal: Harus diisi untuk menentukan hari. Jika kosong, tampilkan pesan error "Tanggal harus diisi."
//        4. Proses Pembelian
//Pengguna memilih jenis tiket.
//Pengguna mengisi data pribadi (nama dan tanggal kunjungan).
//Sistem memeriksa hari berdasarkan tanggal yang diinput dan menyesuaikan harga jika perlu.
//Pengguna melakukan review pesanan dan melanjutkan ke pembayaran.
//        5. Validasi Input
//Semua input wajib diisi.
//Validasi tanggal dilakukan untuk memastikan format tanggal benar dan logis (misal, tidak memasukkan tanggal di masa lalu atau format tanggal salah).