package com.example.libraryapp.sony;

import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class ProductDetailPage {
    private BorderPane view;

    public ProductDetailPage(String productName, Image productImage, String productDescriptionText, String productPriceText) {
        view = new BorderPane();
        view.setStyle("-fx-background-color: white;");

        // Header
        HBox header = new HBox();
        header.setStyle("-fx-background-color: #000000; -fx-padding: 10; -fx-alignment: center;");
        Button backButton = new Button("Kembali ke Produk");
        backButton.setStyle("-fx-background-color: #000000; -fx-text-fill: white;");
        Label titleLabel = new Label(productName);
        titleLabel.setStyle("-fx-text-fill: white; -fx-font-size: 18px;");


        backButton.setOnAction(e -> Main.changeScene(new ProductPage("Sony").getView()));

        header.getChildren().addAll(backButton, titleLabel);

        // Detail Produk
        ImageView productImageView = new ImageView(productImage);
        productImageView.setStyle("-fx-padding: 10;");

        TextArea productDescription = new TextArea(productDescriptionText);
        productDescription.setWrapText(true);
        productDescription.setEditable(false);
        productDescription.setStyle("-fx-padding: 10; -fx-text-fill: black;");

        Label productPrice = new Label("Harga: " + productPriceText);
        productPrice.setStyle("-fx-padding: 10; -fx-text-fill: #00c700;");

        Button addToCartButton = new Button("Tambah ke Keranjang");
        addToCartButton.setStyle("-fx-background-color: #000000; -fx-text-fill: white;");
        addToCartButton.setOnAction(e -> {
            if (Main.isUserLoggedIn()) {
                CartPage.addItem(new CartItem(productName, productImage));
                Alert alert = new Alert(AlertType.INFORMATION);
                alert.setTitle("Produk Ditambahkan");
                alert.setHeaderText(null);
                alert.setContentText("Produk telah ditambahkan ke keranjang.");
                alert.showAndWait();
            } else {
                Main.changeScene(new LoginPage().getView());
            }
        });

        VBox productDetailBox = new VBox(productImageView, productDescription, productPrice, addToCartButton);
        productDetailBox.setStyle("-fx-padding: 20;");
        productDetailBox.setAlignment(Pos.TOP_CENTER);

        view.setTop(header);
        view.setCenter(productDetailBox);
    }

    public BorderPane getView() {
        return view;
    }
}
