package com.example.libraryapp.sony;

import javafx.scene.image.Image;

public class CartItem {
    private String name;
    private Image image;

    public CartItem(String name, Image image) {
        this.name = name;
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public Image getImage() {
        return image;
    }

    public Image getProductImage() {
        return getImage();
    }

    public String getProductName() {
        return getName();
    }
}
