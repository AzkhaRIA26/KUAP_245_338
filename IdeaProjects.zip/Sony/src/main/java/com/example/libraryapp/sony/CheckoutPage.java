// CheckoutPage.java
package com.example.libraryapp.sony;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ScrollPane;

import java.util.List;

public class CheckoutPage {
    private BorderPane view;
    private List<CartItem> cartItems;

    public CheckoutPage(List<CartItem> cartItems) {
        this.cartItems = cartItems;
        view = new BorderPane();
        view.getStyleClass().add("root");

        VBox checkoutBox = new VBox();
        checkoutBox.setPadding(new Insets(20));
        checkoutBox.setSpacing(10);
        checkoutBox.setAlignment(Pos.CENTER);

        Label cartLabel = new Label("Keranjang Anda:");
        cartLabel.setStyle("-fx-text-fill: #000000;");
        checkoutBox.getChildren().add(cartLabel);

        for (CartItem item : cartItems) {
            Label itemLabel = new Label(item.getProductName());
            itemLabel.setStyle("-fx-text-fill: #000000;");
            checkoutBox.getChildren().add(itemLabel);
        }

        Label nameLabel = new Label("Nama:");
        nameLabel.setStyle("-fx-text-fill: #000000;");
        TextField nameField = new TextField();

        Label addressLabel = new Label("Alamat:");
        addressLabel.setStyle("-fx-text-fill: #000000;");
        TextField addressField = new TextField();

        Label emailLabel = new Label("Email:");
        emailLabel.setStyle("-fx-text-fill: #000000;");
        TextField emailField = new TextField();

        Label phoneLabel = new Label("Nomor Telepon:");
        phoneLabel.setStyle("-fx-text-fill: #000000;");
        TextField phoneField = new TextField();

        Label paymentLabel = new Label("Metode Pembayaran:");
        paymentLabel.setStyle("-fx-text-fill: #000000;");
        ToggleGroup paymentGroup = new ToggleGroup();
        RadioButton creditCardOption = new RadioButton("Kartu Kredit");
        creditCardOption.setStyle("-fx-text-fill: #000000;");
        creditCardOption.setToggleGroup(paymentGroup);
        RadioButton debitCardOption = new RadioButton("Kartu Debit");
        debitCardOption.setStyle("-fx-text-fill: #000000;");
        debitCardOption.setToggleGroup(paymentGroup);

        VBox paymentBox = new VBox(creditCardOption, debitCardOption);
        paymentBox.setSpacing(5);
        paymentBox.setAlignment(Pos.CENTER_LEFT);

        Label cardLabel = new Label("Nomor Kartu:");
        cardLabel.setStyle("-fx-text-fill: #000000;");
        TextField cardField = new TextField();
        cardField.setPromptText("Masukkan nomor kartu Anda");
        cardField.setStyle("-fx-text-fill: #0000ff;");

        // Update UI based on selected payment method
        paymentGroup.selectedToggleProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null) {
                RadioButton selectedRadioButton = (RadioButton) newValue;
                String selectedPaymentMethod = selectedRadioButton.getText();
                cardField.setPromptText("Masukkan nomor " + selectedPaymentMethod.toLowerCase() + " Anda");
            }
        });

        Button payButton = new Button("Bayar");
        payButton.setStyle("-fx-background-color: #000000; -fx-text-fill: white;");
        payButton.getStyleClass().add("button");

        payButton.setOnAction(e -> {
            System.out.println("Proses pembayaran dimulai.");
            // Show a success notification
            Alert alert = new Alert(AlertType.INFORMATION);
            alert.setTitle("Pembayaran Berhasil");
            alert.setHeaderText(null);
            alert.setContentText("Pembayaran Anda telah berhasil!");
            alert.showAndWait();
        });

        checkoutBox.getChildren().addAll(nameLabel, nameField, addressLabel, addressField, emailLabel, emailField, phoneLabel, phoneField, paymentLabel, paymentBox, cardLabel, cardField, payButton);

        ScrollPane scrollPane = new ScrollPane(checkoutBox);
        scrollPane.setFitToWidth(true);

        view.setCenter(scrollPane);
    }

    public BorderPane getView() {
        return view;
    }
}
