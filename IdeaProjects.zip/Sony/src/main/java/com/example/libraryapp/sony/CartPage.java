// CartPage.java
package com.example.libraryapp.sony;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;

import java.util.ArrayList;
import java.util.List;

public class CartPage {
    private static List<CartItem> cartItems = new ArrayList<>();
    private BorderPane view;

    public CartPage() {
        view = new BorderPane();
        view.setStyle("-fx-background-color: white;");

        // Header
        HBox header = new HBox();
        header.setStyle("-fx-background-color: #000000; -fx-padding: 10; -fx-alignment: center;");
        Label titleLabel = new Label("Keranjang");
        titleLabel.setStyle("-fx-text-fill: white; -fx-font-size: 18px;");
        Button backButton = new Button("Kembali ke Beranda");
        backButton.setStyle("-fx-background-color: #000000; -fx-text-fill: white;");


        backButton.setOnAction(e -> Main.changeScene(new HomePage().getView()));

        header.getChildren().addAll(titleLabel, backButton);

        // Keranjang
        VBox cartBox = new VBox();
        cartBox.setPadding(new Insets(20));
        cartBox.setSpacing(10);

        for (CartItem item : cartItems) {
            HBox itemBox = new HBox();
            itemBox.setSpacing(10);
            itemBox.setAlignment(Pos.CENTER_LEFT);

            ImageView productImageView = new ImageView(item.getProductImage());
            productImageView.setFitHeight(50);
            productImageView.setFitWidth(50);

            Label productNameLabel = new Label(item.getProductName());
            productNameLabel.setStyle("-fx-text-fill: black;");

            Button removeButton = new Button("Hapus");
            removeButton.setStyle("-fx-background-color: #000000; -fx-text-fill: white;");
            removeButton.setOnAction(e -> {
                cartItems.remove(item);
                Main.changeScene(new CartPage().getView());
            });

            itemBox.getChildren().addAll(productImageView, productNameLabel, removeButton);
            cartBox.getChildren().add(itemBox);
        }

        // Checkout Button
        Button checkoutButton = new Button("Checkout");
        checkoutButton.setStyle("-fx-background-color: #000000; -fx-text-fill: white;");
        checkoutButton.setOnAction(e -> Main.changeScene(new CheckoutPage(cartItems).getView()));
        cartBox.getChildren().add(checkoutButton);

        view.setTop(header);
        view.setCenter(cartBox);
    }

    public static void addItem(CartItem item) {
        cartItems.add(item);
    }

    public BorderPane getView() {
        return view;
    }
}
