package com.example.libraryapp.sony;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.util.List;

public class ProductPage {
    private BorderPane view;
    private String brand;
    private List<Product> products;

    public ProductPage(String brand) {
        this.brand = brand;
        this.products = loadProducts();
        view = new BorderPane();
        view.setStyle("-fx-background-color: white;");

        // Header
        HBox header = new HBox();
        header.setStyle("-fx-background-color: #000000; -fx-padding: 10; -fx-alignment: center;");
        Button backButton = new Button("Kembali ke Beranda");
        backButton.setStyle("-fx-background-color: #000000; -fx-text-fill: white;");
        Label titleLabel = new Label("Produk " + brand);
        titleLabel.setStyle("-fx-text-fill: white; -fx-font-size: 18px;");

        backButton.setOnAction(e -> Main.changeScene(new HomePage().getView()));

        header.getChildren().addAll(backButton, titleLabel);

        // Daftar Produk
        GridPane productGrid = new GridPane();
        productGrid.setStyle("-fx-padding: 20; -fx-hgap: 20; -fx-vgap: 20;");

        int column = 0;
        int row = 0;

        for (Product product : products) {
            if (!product.getBrand().equalsIgnoreCase(brand)) {
                continue;
            }

            Image productImage = new Image(getClass().getResource(product.getImagePath()).toExternalForm());
            ImageView productImageView = new ImageView(productImage);
            productImageView.setStyle("-fx-padding: 10;");

            Label productName = new Label(product.getName());
            productName.setStyle("-fx-padding: 10; -fx-text-fill: black;");

            Button detailButton = new Button("Detail");
            detailButton.setStyle("-fx-background-color: #000000; -fx-text-fill: white;");
            Button addToCartButton = new Button("Tambah ke Keranjang");
            addToCartButton.setStyle("-fx-background-color: #000000; -fx-text-fill: white;");

            detailButton.setOnAction(e -> {
                ProductDetailPage productDetailPage = new ProductDetailPage(product.getName(), productImage, product.getDescription(), product.getPrice());
                Main.changeScene(productDetailPage.getView());
            });

            addToCartButton.setOnAction(e -> {
                if (Main.isUserLoggedIn()) {
                    CartPage.addItem(new CartItem(product.getName(), productImage));
                    Alert alert = new Alert(AlertType.INFORMATION);
                    alert.setTitle("Produk Ditambahkan");
                    alert.setHeaderText(null);
                    alert.setContentText("Produk telah ditambahkan ke keranjang.");
                    alert.showAndWait();
                } else {
                    Main.changeScene(new LoginPage().getView());
                }
            });

            VBox productBox = new VBox(productImageView, productName, detailButton, addToCartButton);
            productBox.setSpacing(10);
            productGrid.add(productBox, column, row);
            productBox.setStyle("-fx-padding: 10; -fx-background-color: #f0f0f0; -fx-alignment: center;");

            column++;
            if (column == 2) {
                column = 0;
                row++;
            }
        }

        ScrollPane scrollPane = new ScrollPane(productGrid);
        scrollPane.setFitToWidth(true);

        view.setTop(header);
        view.setCenter(scrollPane);
    }

    private List<Product> loadProducts() {
        Gson gson = new Gson();
        InputStreamReader reader = new InputStreamReader(getClass().getResourceAsStream("/css/products.json"));
        Type productListType = new TypeToken<List<Product>>() {}.getType();
        return gson.fromJson(reader, productListType);
    }

    public BorderPane getView() {
        return view;
    }
}
