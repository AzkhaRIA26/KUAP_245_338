package com.example.libraryapp.sony;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class HomePage {
    private BorderPane view;

    public HomePage() {
        view = new BorderPane();
        view.getStyleClass().add("root");

        // Header
        HBox header = createHeader();

        // Banner
        Image bannerImage = new Image(getClass().getResource("/images/sonyy.jpg").toExternalForm());
        ImageView bannerImageView = new ImageView(bannerImage);
        bannerImageView.getStyleClass().add("image-view");

        VBox bannerBox = new VBox(bannerImageView);
        bannerBox.getStyleClass().add("banner");
        bannerBox.setAlignment(Pos.CENTER);

        view.setTop(header);
        view.setCenter(bannerBox);
    }

    private HBox createHeader() {
        HBox header = new HBox();
        header.getStyleClass().add("header");
        header.setSpacing(20);
        header.setPadding(new Insets(10));
        header.setAlignment(Pos.CENTER_LEFT);

        // Logo
        Label titleLabel = new Label("Pixel Perfect");
        titleLabel.getStyleClass().add("label-large");

        // Navigation
        Button sonyButton = new Button("Sony");
        Button canonButton = new Button("Canon");
        Button nikonButton = new Button("Nikon");
        Button soldButton = new Button ("Sold Out" );
        sonyButton.getStyleClass().add("button");
        canonButton.getStyleClass().add("button");
        nikonButton.getStyleClass().add("button");
        soldButton.getStyleClass().add("button");

        sonyButton.setOnAction(e -> Main.changeScene(new ProductPage("Sony").getView()));
        canonButton.setOnAction(e -> Main.changeScene(new ProductPage("Canon").getView()));
        nikonButton.setOnAction(e -> Main.changeScene(new ProductPage("Nikon").getView()));
        soldButton.setOnAction(e -> Main.changeScene(new ProductPage("Sold Out").getView()));

        // Search Bar
        ImageView searchIcon = new ImageView(new Image(getClass().getResourceAsStream("/images/Search.png")));
        searchIcon.setFitWidth(20);  // Set width as per your requirement
        searchIcon.setFitHeight(20); // Set height as per your requirement
        Button searchButton = new Button();
        searchButton.setGraphic(searchIcon);
        searchButton.getStyleClass().add("button");

        TextField searchField = new TextField();
        searchField.setPromptText("Search");

        // Cart and Login
        ImageView cartIcon = new ImageView(new Image(getClass().getResourceAsStream("/images/keranjang.jpg")));
        cartIcon.setFitWidth(20);  // Set width as per your requirement
        cartIcon.setFitHeight(20); // Set height as per your requirement
        Button cartButton = new Button();
        cartButton.setGraphic(cartIcon);
        cartButton.getStyleClass().add("button");
        cartButton.setOnAction(e -> Main.changeScene(new CartPage().getView()));

        Button loginButton = new Button("Login");
        loginButton.getStyleClass().add("button");
        loginButton.setOnAction(e -> Main.changeScene(new LoginPage().getView()));

        header.getChildren().addAll(titleLabel, sonyButton, canonButton, nikonButton, soldButton, searchField, searchButton, cartButton, loginButton);
        return header;
    }

    public BorderPane getView() {
        return view;
    }
}
