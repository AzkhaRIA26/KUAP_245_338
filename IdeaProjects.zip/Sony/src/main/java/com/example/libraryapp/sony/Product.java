package com.example.libraryapp.sony;

public class Product {
    private String brand;
    private String name;
    private String description;
    private String imagePath;
    private String price;

    public Product(String brand, String name, String description, String imagePath, String price) {
        this.brand = brand;
        this.name = name;
        this.description = description;
        this.imagePath = imagePath;
        this.price = price;
    }

    // Getters
    public String getBrand() {
        return brand;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public String getImagePath() {
        return imagePath;
    }

    public String getPrice() {
        return price;
    }
}
