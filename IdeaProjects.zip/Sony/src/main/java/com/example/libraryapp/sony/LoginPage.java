package com.example.libraryapp.sony;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;

public class LoginPage {
    private BorderPane view;

    public LoginPage() {
        view = new BorderPane();
        view.setStyle("-fx-background-color: white;");

        VBox loginBox = new VBox();
        loginBox.setPadding(new Insets(20));
        loginBox.setSpacing(10);
        loginBox.setAlignment(Pos.CENTER);

        Label usernameLabel = new Label("Username:");
        usernameLabel.setStyle("-fx-text-fill: black;");
        TextField usernameField = new TextField();
        Label passwordLabel = new Label("Password:");
        passwordLabel.setStyle("-fx-text-fill: black;");
        PasswordField passwordField = new PasswordField();
        Button loginButton = new Button("Login");
        loginButton.setStyle("-fx-background-color: #000000; -fx-text-fill: white;");

        loginButton.setOnAction(e -> {
            String username = usernameField.getText();
            String password = passwordField.getText();
            if (Main.authenticateUser(username, password)) {
                Main.setUserLoggedIn(true);
                Main.changeScene(new HomePage().getView());
            } else {
                System.out.println("Login gagal. Silakan coba lagi.");
            }
        });

        loginBox.getChildren().addAll(usernameLabel, usernameField, passwordLabel, passwordField, loginButton);
        view.setCenter(loginBox);
    }

    public BorderPane getView() {
        return view;
    }
}
