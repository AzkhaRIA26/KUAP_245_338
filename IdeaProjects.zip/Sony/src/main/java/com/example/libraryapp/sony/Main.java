package com.example.libraryapp.sony;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class Main extends Application {
    private static Stage primaryStage;
    private static boolean userLoggedIn = false;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        Main.primaryStage = primaryStage;
        primaryStage.setTitle("Pixel Perfect");
        primaryStage.getIcons().add(new Image(Main.class.getResourceAsStream("/images/logo.jpg")));
        changeScene(new HomePage().getView());
        primaryStage.show();
    }

    public static void changeScene(BorderPane view) {
        Scene scene = new Scene(view, 1200, 760);
        scene.getStylesheets().add(Main.class.getResource("/css/styles.css").toExternalForm());
        primaryStage.setScene(scene);
    }

    public static boolean authenticateUser(String username, String password) {
        return "user".equals(username) && "password".equals(password);
    }

    public static boolean isUserLoggedIn() {
        return userLoggedIn;
    }

    public static void setUserLoggedIn(boolean loggedIn) {
        userLoggedIn = loggedIn;
    }
}
