module com.example.libraryapp.sony {
    requires javafx.controls;
    requires javafx.fxml;
    requires com.google.gson;

    opens com.example.libraryapp.sony to javafx.fxml, com.google.gson;
    exports com.example.libraryapp.sony;
}
