//package Tugas3;
//
//public class Main {
//    public static void main(String[] args) {
//        info infoPenumpang = new info("Korban Ghosting", "Tokyo", "Kyoto", 1000000, 10);
//        TiketPesawat tiket = new TiketPesawat(infoPenumpang);
//        tiket.tampilkanInformasi();
//    }
//}
//
