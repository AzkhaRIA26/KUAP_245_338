package test;

import static org.junit.Assert.assertEquals;
import org.junit.Test;

import maintest.MaxFinder;

public class MaxFinderTest {

    // Pengujian angka 3 dari nilai a, b, dan c yang bernilai 1, 2, dan 3
    @Test
    public void testFindMax_123() {
        assertEquals(3, MaxFinder.findMax(1, 2, 3));
    }

    // Pengujian angka -1 dari nilai a, b, dan c yang bernilai -1, -2, dan -3
    @Test
    public void testFindMax_negatives() {
        assertEquals(-1, MaxFinder.findMax(-1, -2, -3));
    }

    // Pengujian angka 0 dari nilai a, b, dan c yang bernilai 0, 0, dan 1
    @Test
    public void testFindMax_zeros() {
        assertEquals(1, MaxFinder.findMax(0, 0, 1));
    }

    // Pengujian tambahan untuk kasus yang lain
    @Test
    public void testFindMax_sameNumbers() {
        // Ketiga nilai sama
        assertEquals(2, MaxFinder.findMax(2, 2, 2));
    }

    @Test
    public void testFindMax_largeNumbers() {
        // Bilangan besar
        assertEquals(1000000, MaxFinder.findMax(1000000, 999999, 500000));
    }
}

