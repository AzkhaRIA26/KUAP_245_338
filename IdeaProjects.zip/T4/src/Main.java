import java.util.ArrayList;

class Gundam {
    private String nama;
    private double harga;
    private int stok;

    public Gundam(String nama, double harga, int stok) {
        this.nama = nama;
        this.harga = harga;
        this.stok = stok;
    }

    // Getter methods
    public String getNama() {
        return nama;
    }

    public double getHarga() {
        return harga;
    }

    public int getStok() {
        return stok;
    }
}

class Pelanggan {
    private String nama;
    private ArrayList<Gundam> keranjang = new ArrayList<>();

    public Pelanggan(String nama) {
        this.nama = nama;
    }

    public void tambahKeKeranjang(Gundam gundam) {
        keranjang.add(gundam);
    }

    // Getter for the name
    public String getNama() {
        return nama;
    }

    // Getter for keranjang
    public ArrayList<Gundam> getKeranjang() {
        return keranjang;
    }
}

class Transaksi {
    private Pelanggan pelanggan;

    public Transaksi(Pelanggan pelanggan) {
        this.pelanggan = pelanggan;
    }

    // Refactored prosesTransaksi method
    public void prosesTransaksi() {
        cetakInfoPelanggan();
        cetakDaftarBelanja();
        double total = hitungTotalHarga();
        System.out.println("Total Harga: Rp " + total);
    }

    private void cetakInfoPelanggan() {
        System.out.println("Pelanggan: " + pelanggan.getNama());
    }

    private void cetakDaftarBelanja() {
        System.out.println("Daftar Belanja:");
        for (Gundam g : pelanggan.getKeranjang()) {
            System.out.println(g.getNama() + " - Rp " + g.getHarga());
        }
    }

    private double hitungTotalHarga() {
        double total = 0;
        for (Gundam g : pelanggan.getKeranjang()) {
            total += g.getHarga();
        }
        return total;
    }
}

public class Main {
    public static void main(String[] args) {
        // Daftar produk
        Gundam gundam1 = new Gundam("Gundam RX-78-2", 500000, 10);
        Gundam gundam2 = new Gundam("Gundam Barbatos", 750000, 5);

        // Membuat pelanggan
        Pelanggan pelanggan1 = new Pelanggan("Andi");

        // Pelanggan membeli gundam
        pelanggan1.tambahKeKeranjang(gundam1);
        pelanggan1.tambahKeKeranjang(gundam2);

        // Proses transaksi
        Transaksi transaksi1 = new Transaksi(pelanggan1);
        transaksi1.prosesTransaksi();
    }
}
