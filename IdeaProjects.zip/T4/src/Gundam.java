//import java.util.ArrayList;
//import java.util.Scanner;
//
//class Gundam {
//    String nama;
//    double harga;
//    int stok;
//
//    public Gundam(String nama, double harga, int stok) {
//        this.nama = nama;
//        this.harga = harga;
//        this.stok = stok;
//    }
//}
//
//class Pelanggan {
//    String nama;
//    ArrayList<Gundam> keranjang = new ArrayList<>();
//
//    public Pelanggan(String nama) {
//        this.nama = nama;
//    }
//
//    public void tambahKeKeranjang(Gundam gundam) {
//        keranjang.add(gundam);
//    }
//}
//
//class Transaksi {
//    Pelanggan pelanggan;
//
//    public Transaksi(Pelanggan pelanggan) {
//        this.pelanggan = pelanggan;
//    }
//
//    public void prosesTransaksi() {
//        double total = 0;
//        System.out.println("Pelanggan: " + pelanggan.nama);
//        System.out.println("Daftar Belanja:");
//        for (Gundam g : pelanggan.keranjang) {
//            System.out.println(g.nama + " - " + g.harga);
//            total += g.harga;
//        }
//        System.out.println("Total Harga: " + total);
//    }
//}
//
//public class Main {
//    public static void main(String[] args) {
//        // Daftar produk
//        Gundam gundam1 = new Gundam("Gundam RX-78-2", 500000, 10);
//        Gundam gundam2 = new Gundam("Gundam Barbatos", 750000, 5);
//
//        // Membuat pelanggan
//        Pelanggan pelanggan1 = new Pelanggan("Andi");
//
//        // Pelanggan membeli gundam
//        pelanggan1.tambahKeKeranjang(gundam1);
//        pelanggan1.tambahKeKeranjang(gundam2);
//
//        // Proses transaksi
//        Transaksi transaksi1 = new Transaksi(pelanggan1);
//        transaksi1.prosesTransaksi();
//    }
//}
