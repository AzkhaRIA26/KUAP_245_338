// Inventory class
public class Inventory {
    // Encapsulate Field
    private Product product;
    private String location;

    // Constructor
    public Inventory(Product product, String location) {
        this.product = product;
        this.location = location;
    }

    // Getter and Setter for product
    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    // Getter and Setter for location
    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    // Show inventory information
    public void showInventory() {
        System.out.println("Location: " + getLocation());
        getProduct().displayProduct();
    }
}
