public class Product {
    // Encapsulate Field
    private String name;
    private double price;
    private int stock;

    // Introduce Constant for discount rate
    private static final double DISCOUNT_RATE = 0.9; // 10% discount

    // Constructor
    public Product(String name, double price, int stock) {
        this.name = name;
        this.price = price;
        this.stock = stock;
    }

    // Getter and Setter for name
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    // Getter and Setter for price
    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    // Getter and Setter for stock
    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    // Display product information (refactored using extract method and inline variable)
    public void displayProduct() {
        System.out.println("Product Name: " + getName());
        System.out.println("Price: $" + getPrice());
        System.out.println("Discounted Price: $" + calculateDiscount()); // using extracted method
        System.out.println("Stock: " + getStock());
    }

    // Extracted method for calculating discount
    private double calculateDiscount() {
        return getPrice() * DISCOUNT_RATE;
    }

    // Apply stock adjustment
    public void applyStockAdjustment(int adjustment) {
        setStock(getStock() + adjustment);  // Using setter to adjust stock
        System.out.println("Stock adjusted. New stock: " + getStock());
    }
}

