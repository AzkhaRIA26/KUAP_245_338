// Main class
public class Main {
    public static void main(String[] args) {
        // Create a product and inventory
        Product prod = new Product("Smartphone", 699.99, 50);
        Inventory inv = new Inventory(prod, "Warehouse A");

        // Show inventory and adjust stock
        inv.showInventory();
        prod.applyStockAdjustment(10);
        inv.showInventory();
        prod.setName("Smartphone Pro");
        prod.setPrice(799.99);
        prod.setStock(30);
        inv.setLocation("Warehouse B");
        inv.showInventory();

        Product newProd = new Product("Tablet", 399.99, 20);
        inv.setProduct(newProd);
        inv.showInventory();
    }
}
